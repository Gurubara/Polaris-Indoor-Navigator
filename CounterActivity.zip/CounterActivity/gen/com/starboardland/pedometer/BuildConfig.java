/** Automatically generated file. DO NOT MODIFY */
package com.starboardland.pedometer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}